
import React from 'react';
import { Target, Users, ShieldCheck, Sparkle } from 'lucide-react';

const About: React.FC = () => {
  const stats = [
    { icon: <Target className="w-5 h-5" />, label: 'Réactivité Directe', value: '24h' },
    { icon: <Users className="w-5 h-5" />, label: 'Experts Dédiés', value: '15+' },
    { icon: <ShieldCheck className="w-5 h-5" />, label: 'Qualité Certifiée', value: 'Elite' },
  ];

  return (
    <section id="about" className="py-32 bg-express-cream relative overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-12 gap-16 items-center">
          
          <div className="lg:col-span-6 relative">
            <div className="relative z-10 rounded-[3rem] overflow-hidden shadow-[0_50px_100px_rgba(0,48,73,0.15)] aspect-[4/5] border-[12px] border-white">
              <img 
                src="https://images.unsplash.com/photo-1542314831-068cd1dbfeeb?auto=format&fit=crop&q=80&w=1200" 
                alt="Luxury Moroccan Riad Entrance" 
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-express-navy/20 to-transparent"></div>
            </div>
            
            {/* Design accents */}
            <div className="absolute -top-10 -left-10 w-40 h-40 bg-express-red/5 rounded-full blur-3xl"></div>
            <div className="absolute -bottom-10 -right-10 w-56 h-56 bg-express-gold/10 rounded-full blur-3xl"></div>
            
            <div className="absolute bottom-10 -right-6 bg-express-navy p-8 rounded-3xl shadow-2xl z-20 max-w-[280px] hidden xl:block border-b-4 border-express-gold">
               <Sparkle className="text-express-gold w-8 h-8 mb-4 animate-pulse" />
               <p className="text-white font-serif italic text-lg leading-relaxed">
                "Plus qu'un voyage, nous sculptons vos plus beaux souvenirs."
              </p>
            </div>
          </div>

          <div className="lg:col-span-6">
            <div className="flex items-center gap-3 mb-8">
              <div className="w-10 h-[1px] bg-express-red"></div>
              <span className="text-express-red font-black tracking-[0.5em] uppercase text-[10px]">L'Âme de l'Agence</span>
            </div>
            
            <h2 className="text-5xl md:text-6xl lg:text-7xl font-serif font-black text-express-navy mb-10 leading-[1.05]">
              L'Excellence <br />
              <span className="text-express-gold italic">au Cœur de</span> <br />
              vos Émotions.
            </h2>
            
            <div className="space-y-6 text-express-teal/70 text-lg leading-relaxed mb-12 font-light">
              <p>
                Basée au cœur battant de Casablanca, <strong className="text-express-navy font-semibold">Moroccan Express Travel Events</strong> est le trait d'union entre vos désirs d'évasion et la réalité du luxe authentique.
              </p>
              <p>
                Qu'il s'agisse de séjours individuels haute couture, de logistique MICE complexe ou de transferts VIP, chaque détail est orchestré avec une précision chirurgicale et une passion indéfectible.
              </p>
            </div>

            <div className="grid grid-cols-3 gap-4">
              {stats.map((stat, idx) => (
                <div key={idx} className="p-6 bg-white rounded-3xl shadow-sm border border-express-navy/5 text-center group hover:bg-express-navy transition-all duration-500 cursor-default">
                  <div className="flex justify-center mb-3 text-express-red group-hover:text-express-gold transition-colors">{stat.icon}</div>
                  <div className="text-express-navy group-hover:text-white font-black text-2xl transition-colors">{stat.value}</div>
                  <div className="text-express-teal/40 group-hover:text-white/40 text-[9px] font-bold uppercase tracking-widest mt-1 transition-colors">{stat.label}</div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default About;
