
import React from 'react';
import { Clock, Network, Sparkles, Scale, CheckCircle2 } from 'lucide-react';

const WhyUs: React.FC = () => {
  const reasons = [
    {
      title: 'Réactivité Chrono',
      desc: 'Réponse garantie en moins de 24h pour vos demandes les plus exigeantes.',
      icon: <Clock className="w-5 h-5" />
    },
    {
      title: 'Réseau de Privilèges',
      desc: 'Accès exclusif à des partenaires hôteliers et logistiques de premier plan.',
      icon: <Network className="w-5 h-5" />
    },
    {
      title: 'Excellence Opérationnelle',
      desc: 'Suivi rigoureux de chaque dossier, de la conception au retour client.',
      icon: <Sparkles className="w-5 h-5" />
    },
    {
      title: 'Éthique Professionnelle',
      desc: 'Transparence totale et respect des engagements contractuels.',
      icon: <Scale className="w-5 h-5" />
    }
  ];

  return (
    <section id="why-us" className="py-32 bg-express-navy relative overflow-hidden">
      {/* Background patterns */}
      <div className="absolute inset-0 opacity-[0.03] pointer-events-none">
        <svg width="100%" height="100%">
          <pattern id="grid" width="40" height="40" patternUnits="userSpaceOnUse">
            <path d="M 40 0 L 0 0 0 40" fill="none" stroke="white" strokeWidth="1"/>
          </pattern>
          <rect width="100%" height="100%" fill="url(#grid)" />
        </svg>
      </div>
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="grid lg:grid-cols-2 gap-24 items-center">
          <div>
            <div className="flex items-center gap-3 mb-8">
              <div className="w-12 h-[1px] bg-express-gold"></div>
              <span className="text-express-gold font-black tracking-[0.5em] uppercase text-[10px]">Notre Différence</span>
            </div>
            
            <h2 className="text-5xl md:text-6xl font-serif font-black text-white mb-10 leading-tight">
              Pourquoi nous confier <br /> <span className="text-express-red italic">vos rêves ?</span>
            </h2>
            
            <p className="text-white/40 text-xl leading-relaxed mb-16 font-light italic border-l-4 border-express-red/30 pl-8">
              "La perfection n'est pas un détail, mais elle naît des détails."
            </p>
            
            <div className="grid sm:grid-cols-2 gap-8">
              {reasons.map((reason, idx) => (
                <div key={idx} className="group p-6 rounded-3xl bg-white/5 border border-white/10 hover:bg-white/[0.08] transition-all duration-500">
                  <div className="w-12 h-12 bg-express-red/20 rounded-2xl flex items-center justify-center text-express-red mb-6 group-hover:scale-110 transition-transform">
                    {reason.icon}
                  </div>
                  <h4 className="text-xl font-bold text-white mb-3 group-hover:text-express-gold transition-colors">{reason.title}</h4>
                  <p className="text-white/50 text-sm leading-relaxed">{reason.desc}</p>
                </div>
              ))}
            </div>
          </div>

          <div className="relative">
             <div className="grid grid-cols-2 gap-6 items-end">
               <div className="space-y-6">
                 <div className="relative rounded-[3rem] overflow-hidden shadow-2xl group">
                   <img 
                    src="https://images.unsplash.com/photo-1445013517791-4197424b23c0?auto=format&fit=crop&q=80&w=600" 
                    alt="Luxury Hotel Pool" 
                    className="w-full h-full object-cover grayscale-[0.2] group-hover:grayscale-0 transition-all duration-700"
                   />
                 </div>
                 <div className="bg-express-gold p-10 rounded-[3rem] text-express-navy shadow-2xl relative overflow-hidden group">
                    <CheckCircle2 className="absolute -bottom-4 -right-4 w-24 h-24 opacity-10 group-hover:scale-125 transition-transform" />
                    <p className="text-5xl font-black mb-2 font-serif tracking-tighter">15+</p>
                    <p className="text-[10px] font-black uppercase tracking-widest opacity-60">Années d'Expertise</p>
                 </div>
               </div>
               <div className="rounded-[3rem] overflow-hidden shadow-2xl aspect-[3/4] border-8 border-white/5 group">
                 <img 
                  src="https://images.unsplash.com/photo-1543831821-27488806203d?auto=format&fit=crop&q=80&w=600" 
                  alt="High-End Travel Gear" 
                  className="w-full h-full object-cover grayscale-[0.2] group-hover:grayscale-0 transition-all duration-700"
                 />
               </div>
             </div>
             
             {/* Glow Effect */}
             <div className="absolute -z-10 top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-express-red/10 blur-[150px] rounded-full"></div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default WhyUs;
