
import React from 'react';
import { Facebook, Instagram, Linkedin, Twitter } from 'lucide-react';
import Logo from './Logo';

const Footer: React.FC = () => {
  return (
    <footer className="bg-express-navy text-white py-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid md:grid-cols-4 gap-12 mb-16">
          <div className="col-span-1 md:col-span-1">
            <div className="mb-6">
              <Logo className="w-10 h-10" showText={true} light={true} />
            </div>
            <p className="text-white/50 text-sm leading-relaxed mb-6">
              Moroccan Express Travel Events conçoit des expériences de voyage uniques, alliant confort, luxe et authenticité. Basé à Casablanca, nous sommes votre partenaire de confiance.
            </p>
            <div className="flex space-x-4">
              <a href="#" className="w-10 h-10 rounded-full border border-white/20 flex items-center justify-center hover:bg-express-gold hover:border-express-gold transition-all"><Facebook size={18} /></a>
              <a href="#" className="w-10 h-10 rounded-full border border-white/20 flex items-center justify-center hover:bg-express-gold hover:border-express-gold transition-all"><Instagram size={18} /></a>
              <a href="#" className="w-10 h-10 rounded-full border border-white/20 flex items-center justify-center hover:bg-express-gold hover:border-express-gold transition-all"><Linkedin size={18} /></a>
              <a href="#" className="w-10 h-10 rounded-full border border-white/20 flex items-center justify-center hover:bg-express-gold hover:border-express-gold transition-all"><Twitter size={18} /></a>
            </div>
          </div>

          <div>
            <h4 className="text-express-gold font-bold uppercase tracking-widest text-xs mb-6">Liens Rapides</h4>
            <ul className="space-y-4 text-white/60 text-sm">
              <li><a href="#about" className="hover:text-express-gold transition-colors">À propos</a></li>
              <li><a href="#services" className="hover:text-express-gold transition-colors">Services</a></li>
              <li><a href="#ai-planner" className="hover:text-express-gold transition-colors">AI Planner</a></li>
              <li><a href="#contact" className="hover:text-express-gold transition-colors">Réservations</a></li>
            </ul>
          </div>

          <div>
            <h4 className="text-express-gold font-bold uppercase tracking-widest text-xs mb-6">Destinations Populaires</h4>
            <ul className="space-y-4 text-white/60 text-sm">
              <li><a href="#" className="hover:text-express-gold transition-colors">Marrakech & Sahara</a></li>
              <li><a href="#" className="hover:text-express-gold transition-colors">Cappadoce & Istanbul</a></li>
              <li><a href="#" className="hover:text-express-gold transition-colors">Asie du Sud-Est</a></li>
              <li><a href="#" className="hover:text-express-gold transition-colors">Capitales Européennes</a></li>
            </ul>
          </div>

          <div>
            <h4 className="text-express-gold font-bold uppercase tracking-widest text-xs mb-6">MICE & Events</h4>
            <ul className="space-y-4 text-white/60 text-sm">
              <li><a href="#" className="hover:text-express-gold transition-colors">Team Building</a></li>
              <li><a href="#" className="hover:text-express-gold transition-colors">Lancements de Produits</a></li>
              <li><a href="#" className="hover:text-express-gold transition-colors">Logistique Transport</a></li>
              <li><a href="#" className="hover:text-express-gold transition-colors">Séminaires VIP</a></li>
            </ul>
          </div>
        </div>

        <div className="border-t border-white/10 pt-8 flex flex-col md:row-reverse md:flex-row justify-between items-center gap-4 text-white/40 text-xs">
          <div className="flex space-x-6">
            <a href="#" className="hover:text-white transition-colors">Politique de Confidentialité</a>
            <a href="#" className="hover:text-white transition-colors">Mentions Légales</a>
          </div>
          <p>© {new Date().getFullYear()} Moroccan Express Travel Events. Tous droits réservés.</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
