
import React, { useState, useEffect } from 'react';
import { Menu, X } from 'lucide-react';
import Logo from './Logo';

const Header: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 50);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navItems = [
    { label: 'À Propos', href: '#about' },
    { label: 'Services', href: '#services' },
    { label: 'AI Planner', href: '#ai-planner' },
    { label: 'Pourquoi Nous?', href: '#why-us' },
    { label: 'Contact', href: '#contact' },
  ];

  return (
    <header 
      className={`fixed w-full z-50 transition-all duration-500 ${
        scrolled ? 'bg-white/95 backdrop-blur-md shadow-lg py-2' : 'bg-transparent py-5'
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center">
          <Logo 
            className="w-10 h-10" 
            showText={true} 
            light={!scrolled} 
          />

          <nav className="hidden md:flex space-x-10 items-center">
            {navItems.map((item) => (
              <a 
                key={item.label} 
                href={item.href}
                className={`text-xs font-bold uppercase tracking-widest transition-all hover:text-express-red relative group/item ${
                  scrolled ? 'text-express-navy' : 'text-white'
                }`}
              >
                {item.label}
                <span className="absolute -bottom-1 left-0 w-0 h-0.5 bg-express-red transition-all group-hover/item:w-full"></span>
              </a>
            ))}
            <a 
              href="#contact" 
              className="bg-express-red hover:bg-express-navy text-white px-8 py-3 rounded-full text-xs font-black uppercase tracking-widest transition-all shadow-xl active:scale-95"
            >
              Réserver
            </a>
          </nav>

          <button className="md:hidden" onClick={() => setIsOpen(!isOpen)}>
            {isOpen ? <X size={28} className="text-express-navy" /> : <Menu size={28} className={scrolled ? 'text-express-navy' : 'text-white'} />}
          </button>
        </div>
      </div>

      {/* Mobile Menu */}
      {isOpen && (
        <div className="md:hidden absolute top-0 left-0 w-full h-screen bg-white z-[60] flex flex-col p-8 animate-in fade-in zoom-in duration-300">
          <div className="flex justify-between items-center mb-12">
            <Logo className="w-12 h-12" />
            <button onClick={() => setIsOpen(false)}><X size={32} className="text-express-navy" /></button>
          </div>
          <div className="space-y-8 flex flex-col flex-grow">
            {navItems.map((item) => (
              <a 
                key={item.label} 
                href={item.href}
                className="text-3xl font-serif font-bold text-express-navy border-b border-express-navy/5 pb-4"
                onClick={() => setIsOpen(false)}
              >
                {item.label}
              </a>
            ))}
          </div>
          <a 
            href="#contact" 
            className="w-full bg-express-red text-white py-6 rounded-2xl text-center font-bold text-xl mb-12 shadow-2xl"
            onClick={() => setIsOpen(false)}
          >
            Réserver maintenant
          </a>
        </div>
      )}
    </header>
  );
};

export default Header;
