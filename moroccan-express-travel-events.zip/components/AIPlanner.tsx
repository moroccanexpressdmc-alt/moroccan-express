
import React, { useState, useEffect } from 'react';
import { GoogleGenAI } from '@google/genai';
import { Wand2, Loader2, Compass, MapPin, Calendar, Sparkles, Image as ImageIcon, Download, Share2, ClipboardList } from 'lucide-react';
import Logo from './Logo';

const LogoOverlay = () => (
  <div className="absolute top-6 left-6 p-4 bg-white/95 backdrop-blur-md rounded-2xl shadow-2xl border border-white/40 opacity-90 group-hover:opacity-100 transition-all duration-500 scale-90 group-hover:scale-100">
    <Logo className="w-12 h-12" showText={true} />
  </div>
);

const AIPlanner: React.FC = () => {
  const [destination, setDestination] = useState('');
  const [duration, setDuration] = useState('Weekend (2-3 jours)');
  const [theme, setTheme] = useState('Luxe & Gastronomie');
  const [itinerary, setItinerary] = useState<string | null>(null);
  const [generatedImageUrl, setGeneratedImageUrl] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [imageLoading, setImageLoading] = useState(false);
  const [loadingMsg, setLoadingMsg] = useState('Analyse de vos préférences...');

  const msgs = [
    'Immersion dans les archives du luxe...',
    'Consultation de notre réseau exclusif...',
    'Sélection des Riads et Palaces...',
    'Orchestration de votre itinéraire...',
    'Signature du carnet de voyage Moroccan Express...'
  ];

  useEffect(() => {
    let interval: any;
    if (loading) {
      let i = 0;
      interval = setInterval(() => {
        setLoadingMsg(msgs[i % msgs.length]);
        i++;
      }, 2500);
    }
    return () => clearInterval(interval);
  }, [loading]);

  const generateItinerary = async () => {
    if (!destination) return;
    setLoading(true);
    setGeneratedImageUrl(null); 
    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      const prompt = `Générez un itinéraire de voyage de prestige pour "${destination}" (${duration}) sur le thème "${theme}".
      L'agence est "Moroccan Express Travel Events". 
      Le ton doit être sophistiqué, inspirant et expert. 
      Structurez en sections "Jour 1", "Jour 2", etc.
      Incluez des lieux "cachés", des tables gastronomiques et des expériences exclusives (ex: vol privé, guide historien).
      Répondez en français de manière très élégante.`;

      const response = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: prompt,
      });

      setItinerary(response.text || "Erreur de génération.");
    } catch (error) {
      console.error('Gemini Error:', error);
      setItinerary("Une erreur est survenue. Veuillez vérifier votre clé API.");
    } finally {
      setLoading(false);
    }
  };

  const generateMoodImage = async () => {
    if (!destination) return;
    setImageLoading(true);
    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      
      // REFINED PROMPT FOR HIGH-END MOROCCAN AUTHENTICITY
      const imagePrompt = `A high-end, editorial travel photograph for Moroccan Express Travel Events featuring ${destination}. 
      The style is 'Bespoke Luxury Architecture' meeting 'Real Authentic Tourism'. 
      Visual elements: Intricate Zellige tilework patterns, textured Tadelakt walls, hand-carved cedar wood details, and lush courtyard gardens. 
      For ${theme} theme: Show grand luxury settings, sun-drenched private terraces, or epic landscapes with an ultra-premium feel. 
      Lighting: Golden hour desert sun, soft cinematic shadows, high dynamic range. 
      Color palette: Saffron gold, deep Majorelle indigo, and emerald green accents. 
      Quality: 8k, sharp focus, professional DSLR photography (Leica style), magazine cover quality. 
      NO TEXT, NO FACES, NO LOGOS. Pure evocative luxury atmosphere.`;
      
      const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash-image',
        contents: { parts: [{ text: imagePrompt }] },
        config: {
          imageConfig: {
            aspectRatio: "16:9"
          }
        }
      });

      for (const part of response.candidates[0].content.parts) {
        if (part.inlineData) {
          const base64EncodeString = part.inlineData.data;
          setGeneratedImageUrl(`data:image/png;base64,${base64EncodeString}`);
          break;
        }
      }
    } catch (error) {
      console.error('Image Generation Error:', error);
    } finally {
      setImageLoading(false);
    }
  };

  return (
    <section id="ai-planner" className="py-32 bg-express-cream">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="glass-card rounded-[3.5rem] overflow-hidden shadow-[0_80px_150px_rgba(0,48,73,0.15)] border-none">
          <div className="bg-express-navy p-12 md:p-20 text-white relative overflow-hidden">
            <div className="relative z-10">
              <div className="flex items-center space-x-3 mb-8">
                <div className="bg-express-gold p-3 rounded-2xl">
                  <Sparkles className="w-6 h-6 text-express-navy" />
                </div>
                <span className="uppercase tracking-[0.4em] text-[10px] font-black text-express-gold">Conciergerie Digitale</span>
              </div>
              <h2 className="text-5xl md:text-7xl font-serif font-black mb-8 leading-tight">Imaginez votre <br /> <span className="text-express-gold italic">Prochaine Odyssée.</span></h2>
              <p className="text-white/60 max-w-2xl text-lg font-light leading-relaxed">
                Notre intelligence artificielle, imprégnée de l'élégance de Casablanca, sculpte pour vous un itinéraire sur-mesure digne des plus grands explorateurs.
              </p>
            </div>
            
            <div className="absolute top-0 right-0 w-[500px] h-[500px] bg-express-gold/10 blur-[120px] -mr-40 -mt-40 rounded-full"></div>
          </div>

          <div className="p-10 md:p-20 bg-white">
            <div className="grid md:grid-cols-3 gap-10 mb-12">
              <div className="space-y-4">
                <label className="text-[10px] font-black text-express-navy uppercase tracking-[0.3em] flex items-center gap-2">
                  <MapPin className="w-4 h-4 text-express-red" /> Destination
                </label>
                <input 
                  type="text" 
                  placeholder="Ex: Marrakech, Chefchaouen, Paris..." 
                  className="w-full bg-express-cream/50 border-b-2 border-express-navy/10 py-5 focus:outline-none focus:border-express-gold transition-all text-xl font-medium"
                  value={destination}
                  onChange={(e) => setDestination(e.target.value)}
                />
              </div>
              <div className="space-y-4">
                <label className="text-[10px] font-black text-express-navy uppercase tracking-[0.3em] flex items-center gap-2">
                  <Calendar className="w-4 h-4 text-express-red" /> Durée
                </label>
                <select 
                  className="w-full bg-transparent border-b-2 border-express-navy/10 py-5 focus:outline-none focus:border-express-gold transition-all text-xl font-medium appearance-none cursor-pointer"
                  value={duration}
                  onChange={(e) => setDuration(e.target.value)}
                >
                  <option>Weekend (2-3 jours)</option>
                  <option>1 Semaine</option>
                  <option>10 Jours</option>
                  <option>2 Semaines</option>
                </select>
              </div>
              <div className="space-y-4">
                <label className="text-[10px] font-black text-express-navy uppercase tracking-[0.3em] flex items-center gap-2">
                  <Compass className="w-4 h-4 text-express-red" /> Style
                </label>
                <select 
                  className="w-full bg-transparent border-b-2 border-express-navy/10 py-5 focus:outline-none focus:border-express-gold transition-all text-xl font-medium appearance-none cursor-pointer"
                  value={theme}
                  onChange={(e) => setTheme(e.target.value)}
                >
                  <option>Luxe & Gastronomie</option>
                  <option>Aventure & Nature</option>
                  <option>Culture & Histoire</option>
                  <option>MICE / Corporate Elite</option>
                </select>
              </div>
            </div>

            <button 
              onClick={generateItinerary}
              disabled={loading || !destination}
              className="group w-full bg-express-navy hover:bg-express-red text-white font-black py-6 rounded-[2rem] shadow-2xl transition-all flex items-center justify-center space-x-3 overflow-hidden relative"
            >
              <span className="relative z-10 flex items-center gap-3 uppercase tracking-widest text-sm">
                {loading ? (
                  <>
                    <Loader2 className="w-6 h-6 animate-spin text-express-gold" />
                    <span>{loadingMsg}</span>
                  </>
                ) : (
                  <>
                    <Wand2 className="w-6 h-6 group-hover:rotate-12 transition-transform" />
                    <span>Concevoir mon Itinéraire Signature</span>
                  </>
                )}
              </span>
            </button>

            {itinerary && (
              <div className="mt-20 animate-in fade-in slide-in-from-bottom-12 duration-1000">
                <div className="bg-express-cream rounded-[3rem] p-10 md:p-16 border border-express-gold/20 shadow-inner relative overflow-hidden">
                  
                  <div className="flex flex-col md:flex-row items-start md:items-center justify-between mb-16 gap-8 relative z-10">
                    <div>
                      <div className="flex items-center gap-3 mb-2">
                        <ClipboardList className="text-express-red w-6 h-6" />
                        <h3 className="text-4xl font-serif font-black text-express-navy">Carnet de Route Exclusif</h3>
                      </div>
                      <p className="text-express-teal/60 uppercase tracking-[0.4em] text-[9px] font-black">Signature Moroccan Express Travel Events</p>
                    </div>
                    <div className="flex gap-4">
                      <button className="bg-white p-4 rounded-2xl text-express-navy hover:text-express-red shadow-md hover:shadow-xl transition-all"><Download size={20} /></button>
                      <button className="bg-express-red text-white px-8 py-4 rounded-2xl font-black uppercase tracking-widest text-xs shadow-xl hover:scale-105 transition-transform">Réserver ce voyage</button>
                    </div>
                  </div>

                  <div className="mb-16 relative group">
                    {!generatedImageUrl ? (
                      <div className="aspect-video rounded-[2.5rem] bg-white border-2 border-dashed border-express-gold/30 flex flex-col items-center justify-center space-y-6">
                        {imageLoading ? (
                          <div className="text-center space-y-4">
                            <Loader2 className="w-10 h-10 text-express-gold animate-spin mx-auto" />
                            <p className="text-express-navy font-serif italic text-xl">Création du visuel de prestige...</p>
                          </div>
                        ) : (
                          <div className="text-center max-w-sm">
                            <h4 className="text-xl font-bold text-express-navy mb-2">Immersion Visuelle</h4>
                            <p className="text-express-teal/60 text-sm mb-6">Laissez l'IA illustrer l'élégance de votre future destination.</p>
                            <button 
                              onClick={generateMoodImage}
                              className="bg-express-navy text-white px-8 py-3 rounded-full font-black uppercase tracking-widest text-[10px] hover:bg-express-red transition-all shadow-lg"
                            >
                              Générer le Visuel Elite
                            </button>
                          </div>
                        )}
                      </div>
                    ) : (
                      <div className="relative rounded-[2.5rem] overflow-hidden shadow-2xl group border-[10px] border-white">
                        <img src={generatedImageUrl} alt="Travel Dream" className="w-full object-cover" />
                        <LogoOverlay />
                        <div className="absolute bottom-0 left-0 w-full p-10 bg-gradient-to-t from-express-navy via-express-navy/40 to-transparent">
                          <p className="text-white font-serif text-4xl italic tracking-tight mb-2">{destination}</p>
                          <div className="flex items-center gap-4">
                            <span className="px-4 py-1.5 bg-express-gold text-express-navy font-black text-[9px] uppercase tracking-widest rounded-full">{theme}</span>
                          </div>
                        </div>
                      </div>
                    )}
                  </div>

                  <div className="prose prose-xl max-w-none text-express-teal/90 leading-relaxed whitespace-pre-wrap border-t border-express-gold/20 pt-12 font-light italic">
                    {itinerary}
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </section>
  );
};

export default AIPlanner;
