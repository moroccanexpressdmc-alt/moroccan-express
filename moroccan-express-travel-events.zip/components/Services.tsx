
import React from 'react';
import { Globe, Ticket, Hotel, Briefcase, Car, ChevronRight } from 'lucide-react';

const Services: React.FC = () => {
  const services = [
    {
      title: 'Séjours sur Mesure',
      desc: 'Des itinéraires haute couture au Maroc et aux confins de l\'Asie, de l\'Europe et de l\'Orient.',
      icon: <Globe className="w-6 h-6" />,
      image: 'https://images.unsplash.com/photo-1544971587-b842c27f8e14?auto=format&fit=crop&q=80&w=1200'
    },
    {
      title: 'Billetterie GDS',
      desc: 'Accès privilégié aux meilleures compagnies aériennes mondiales pour vos vols internationaux.',
      icon: <Ticket className="w-6 h-6" />,
      image: 'https://images.unsplash.com/photo-1436491865332-7a61a109c0f2?auto=format&fit=crop&q=80&w=1200'
    },
    {
      title: 'Hébergement de Luxe',
      desc: 'Une sélection rigoureuse des Riads les plus secrets et des palaces 5 étoiles les plus iconiques.',
      icon: <Hotel className="w-6 h-6" />,
      image: 'https://images.unsplash.com/photo-1571896349842-33c89424de2d?auto=format&fit=crop&q=80&w=1200'
    },
    {
      title: 'MICE & Corporate',
      desc: 'Expertise logistique pour vos séminaires, lancements de produits et team buildings d\'exception.',
      icon: <Briefcase className="w-6 h-6" />,
      image: 'https://images.unsplash.com/photo-1511795409834-ef04bbd61622?auto=format&fit=crop&q=80&w=1200'
    },
    {
      title: 'Transport VIP',
      desc: 'Chauffeurs privés et transferts haut de gamme pour une mobilité sans compromis.',
      icon: <Car className="w-6 h-6" />,
      image: 'https://images.unsplash.com/photo-1549317661-bd32c8ce0db2?auto=format&fit=crop&q=80&w=1200'
    },
  ];

  return (
    <section id="services" className="py-32 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-20 gap-8">
          <div className="max-w-2xl">
            <span className="text-express-gold font-bold tracking-[0.4em] uppercase text-[10px] mb-4 block">Signature Services</span>
            <h2 className="text-5xl font-serif font-black text-express-navy mb-6">
              Une Palette de Services <br /> <span className="text-express-red italic">Sans Frontières.</span>
            </h2>
            <div className="w-20 h-[2px] bg-express-navy/10"></div>
          </div>
          <p className="text-express-teal/60 max-w-sm italic text-sm">
            Notre agence déploie son savoir-faire pour transformer chaque voyage en une œuvre d'art logistique.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {services.map((service, idx) => (
            <div 
              key={idx} 
              className={`group relative overflow-hidden rounded-[2.5rem] shadow-2xl transition-all duration-700 hover:-translate-y-3 h-[500px] ${
                idx === 4 ? 'lg:col-span-1' : ''
              }`}
            >
              <div className="absolute inset-0 z-0">
                <img 
                  src={service.image} 
                  alt={service.title} 
                  className="w-full h-full object-cover transition-transform duration-1000 group-hover:scale-110"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-express-navy via-express-navy/50 to-transparent"></div>
              </div>
              
              <div className="relative z-10 p-10 h-full flex flex-col justify-end">
                <div className="absolute top-10 right-10 w-14 h-14 bg-white/10 backdrop-blur-md rounded-2xl flex items-center justify-center text-express-gold border border-white/20 group-hover:bg-express-gold group-hover:text-express-navy transition-all duration-500">
                  {service.icon}
                </div>
                
                <h3 className="text-3xl font-serif font-bold text-white mb-4 group-hover:text-express-gold transition-colors">{service.title}</h3>
                <p className="text-white/70 leading-relaxed text-sm mb-8 opacity-0 group-hover:opacity-100 transition-all duration-500 translate-y-4 group-hover:translate-y-0">
                  {service.desc}
                </p>
                
                <button className="flex items-center text-[10px] font-black uppercase tracking-[0.3em] text-white/50 group-hover:text-express-gold transition-colors">
                  Explorer ce service <ChevronRight className="ml-2 w-4 h-4" />
                </button>
              </div>
              
              {/* Subtle Shimmer Overlay */}
              <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/5 to-transparent -translate-x-full group-hover:animate-shimmer pointer-events-none"></div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Services;
