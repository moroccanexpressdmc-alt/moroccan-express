
import React from 'react';

interface LogoProps {
  className?: string;
  showText?: boolean;
  textColor?: string;
  light?: boolean;
}

const Logo: React.FC<LogoProps> = ({ className = "w-12 h-12", showText = true, textColor = "text-express-navy", light = false }) => {
  const primaryRed = "#D62828";
  const primaryNavy = light ? "#FFFFFF" : "#003049";
  const primaryGold = "#FCBF49";
  const textCol = light ? "text-white" : textColor;

  return (
    <div className={`flex items-center gap-3 ${className}`}>
      <div className="relative shrink-0 w-full h-full">
        <svg viewBox="0 0 100 100" className="w-full h-full drop-shadow-sm">
          {/* Stylized Red M */}
          <path 
            d="M20 85 L20 25 L35 25 L50 60 L65 25 L80 25 L80 85 L65 85 L65 45 L50 75 L35 45 L35 85 Z" 
            fill={primaryRed} 
          />
          {/* Blue Swoosh */}
          <path d="M15 65 Q 45 35 85 55" fill="none" stroke={primaryNavy} strokeWidth="4" strokeLinecap="round" />
          {/* Red Secondary Swoosh */}
          <path d="M25 75 Q 55 45 90 65" fill="none" stroke={primaryRed} strokeWidth="3" strokeLinecap="round" opacity="0.8" />
          {/* Yellow Plane */}
          <g transform="translate(85, 55) rotate(-35)">
            <path d="M-5 0 L5 0 L0 -8 Z" fill={primaryGold} />
            <rect x="-6" y="-2" width="12" height="1.5" rx="0.5" fill={primaryGold} />
          </g>
        </svg>
      </div>
      {showText && (
        <div className="flex flex-col leading-none">
          <span className={`text-lg font-serif font-medium tracking-tight ${light ? 'text-white' : 'text-express-red'}`}>
            MOROCCAN
          </span>
          <span className={`text-xl font-sans font-black tracking-tighter ${light ? 'text-white' : 'text-express-red'}`}>
            EXPRESS
          </span>
          <span className={`text-[9px] font-sans font-medium tracking-[0.2em] mt-0.5 ${light ? 'text-white/80' : 'text-express-red'}`}>
            Travel events
          </span>
        </div>
      )}
    </div>
  );
};

export default Logo;
