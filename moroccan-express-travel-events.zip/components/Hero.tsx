
import React from 'react';
import { ChevronRight, Globe, Award, ShieldCheck } from 'lucide-react';
import Logo from './Logo';

const Hero: React.FC = () => {
  return (
    <section className="relative h-screen flex items-center overflow-hidden bg-express-navy">
      {/* Dynamic Background Collage */}
      <div className="absolute inset-0 z-0 flex">
        <div className="w-full md:w-3/5 h-full relative overflow-hidden">
          <img 
            src="https://images.unsplash.com/photo-1539020140153-e479b8c22e70?auto=format&fit=crop&q=80&w=1600" 
            alt="Sahara Luxury Camp" 
            className="w-full h-full object-cover animate-pulse-slow brightness-[0.4] scale-105"
          />
        </div>
        <div className="hidden md:grid w-2/5 h-full grid-cols-1 grid-rows-3 gap-1 p-1 bg-express-navy">
          <img src="https://images.unsplash.com/photo-1548013146-72479768bbaa?auto=format&fit=crop&q=80&w=800" className="w-full h-full object-cover brightness-50 opacity-80" alt="Marrakech Architecture" />
          <img src="https://images.unsplash.com/photo-1523302228240-6106fb04c102?auto=format&fit=crop&q=80&w=800" className="w-full h-full object-cover brightness-50 opacity-80" alt="Luxury Riad" />
          <img src="https://images.unsplash.com/photo-1596492784531-6e6eb5ea9993?auto=format&fit=crop&q=80&w=800" className="w-full h-full object-cover brightness-50 opacity-80" alt="Casablanca Coastal" />
        </div>
        <div className="absolute inset-0 bg-gradient-to-r from-express-navy via-express-navy/60 to-transparent"></div>
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="max-w-4xl">
          <div className="flex items-center gap-4 mb-8 animate-in fade-in slide-in-from-left-8 duration-700">
            <div className="h-[1px] w-20 bg-express-gold"></div>
            <span className="text-express-gold text-[10px] font-black uppercase tracking-[0.6em]">
              L'Art du Voyage d'Exception
            </span>
          </div>
          
          <h1 className="text-6xl md:text-8xl lg:text-[110px] font-serif font-black text-white leading-[0.9] mb-8 animate-in fade-in slide-in-from-left-12 duration-1000 delay-100">
            L'ÉVASION <br />
            <span className="text-express-gold italic font-bold">RE-DÉFINIE.</span>
          </h1>
          
          <p className="text-xl md:text-2xl text-white/80 font-serif italic mb-12 max-w-2xl animate-in fade-in slide-in-from-left-8 duration-1000 delay-200 leading-relaxed">
            Partez à la découverte du monde avec une agence qui sublime chaque instant de votre parcours.
          </p>
          
          <div className="flex flex-col sm:flex-row gap-6 mb-16 animate-in fade-in slide-in-from-bottom-8 duration-1000 delay-300">
            <a 
              href="#ai-planner" 
              className="group relative bg-express-red hover:bg-white hover:text-express-navy text-white px-12 py-5 rounded-full text-sm font-black uppercase tracking-widest flex items-center justify-center transition-all shadow-[0_20px_50px_rgba(214,40,40,0.3)] overflow-hidden"
            >
              <span className="relative z-10 flex items-center">
                Créer mon itinéraire IA
                <ChevronRight className="ml-2 group-hover:translate-x-2 transition-transform" />
              </span>
              <div className="absolute inset-0 bg-white translate-y-full group-hover:translate-y-0 transition-transform duration-300"></div>
            </a>
            
            <div className="flex items-center gap-10 px-6 border-l border-white/10 ml-0 sm:ml-4">
              <div className="text-center group cursor-default">
                <Globe className="w-5 h-5 text-express-gold mx-auto mb-2 group-hover:scale-110 transition-transform" />
                <span className="text-[9px] text-white/40 font-bold uppercase tracking-[0.2em]">Réseau Global</span>
              </div>
              <div className="text-center group cursor-default">
                <Award className="w-5 h-5 text-express-gold mx-auto mb-2 group-hover:scale-110 transition-transform" />
                <span className="text-[9px] text-white/40 font-bold uppercase tracking-[0.2em]">Service Élite</span>
              </div>
              <div className="text-center group cursor-default">
                <ShieldCheck className="w-5 h-5 text-express-gold mx-auto mb-2 group-hover:scale-110 transition-transform" />
                <span className="text-[9px] text-white/40 font-bold uppercase tracking-[0.2em]">Sécurité Totale</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Decorative Large Logo Watermark */}
      <div className="absolute -bottom-20 -right-20 hidden xl:block opacity-5 pointer-events-none rotate-[-15deg]">
        <Logo className="w-[600px] h-[600px]" showText={false} />
      </div>
    </section>
  );
};

export default Hero;
