
import React from 'react';
import { Mail, Phone, MapPin, Send, MessageSquare } from 'lucide-react';

const Contact: React.FC = () => {
  return (
    <section id="contact" className="py-32 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-express-cream rounded-[3.5rem] overflow-hidden shadow-[0_50px_100px_rgba(0,48,73,0.1)] flex flex-col lg:flex-row border border-express-navy/5">
          <div className="bg-express-navy p-12 md:p-20 text-white lg:w-2/5 relative overflow-hidden">
            <div className="relative z-10">
              <span className="text-express-gold font-black uppercase tracking-[0.4em] text-[10px] mb-6 block">Conciergerie</span>
              <h2 className="text-4xl md:text-5xl font-serif font-black mb-8 leading-tight">Parlons de votre <br /> <span className="text-express-gold italic">Prochain Départ.</span></h2>
              <p className="text-white/50 mb-16 text-lg font-light leading-relaxed">
                Notre équipe basée à Casablanca orchestre vos projets les plus ambitieux avec discrétion et prestige.
              </p>

              <div className="space-y-10">
                <div className="flex items-center gap-6 group cursor-pointer">
                  <div className="bg-white/5 p-4 rounded-2xl text-express-gold group-hover:bg-express-gold group-hover:text-express-navy transition-all duration-500">
                    <MapPin className="w-6 h-6" />
                  </div>
                  <div>
                    <h4 className="font-bold text-sm uppercase tracking-widest text-white/40 mb-1">Siège</h4>
                    <p className="text-white font-serif text-lg">Casablanca, Maroc</p>
                  </div>
                </div>
                <div className="flex items-center gap-6 group cursor-pointer">
                  <div className="bg-white/5 p-4 rounded-2xl text-express-gold group-hover:bg-express-gold group-hover:text-express-navy transition-all duration-500">
                    <Phone className="w-6 h-6" />
                  </div>
                  <div>
                    <h4 className="font-bold text-sm uppercase tracking-widest text-white/40 mb-1">Contact Direct</h4>
                    <p className="text-white font-serif text-lg">+212 (0) 522 XX XX XX</p>
                  </div>
                </div>
                <div className="flex items-center gap-6 group cursor-pointer">
                  <div className="bg-white/5 p-4 rounded-2xl text-express-gold group-hover:bg-express-gold group-hover:text-express-navy transition-all duration-500">
                    <Mail className="w-6 h-6" />
                  </div>
                  <div>
                    <h4 className="font-bold text-sm uppercase tracking-widest text-white/40 mb-1">Email</h4>
                    <p className="text-white font-serif text-lg">contact@moroccanexpress.travel</p>
                  </div>
                </div>
              </div>
            </div>
            
            {/* Design accents */}
            <div className="absolute top-0 right-0 w-64 h-64 bg-express-gold/5 blur-[80px] rounded-full -mr-32 -mt-32"></div>
            <div className="absolute bottom-0 left-0 w-40 h-40 bg-express-red/10 blur-[60px] rounded-full -ml-20 -mb-20"></div>
          </div>

          <div className="p-12 md:p-20 lg:w-3/5 bg-white">
            <div className="flex items-center gap-3 mb-10">
              <MessageSquare className="text-express-red w-5 h-5" />
              <h3 className="text-2xl font-serif font-black text-express-navy tracking-tight">Soumettre une demande de devis</h3>
            </div>
            
            <form className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <div className="space-y-3">
                <label className="text-[10px] font-black text-express-navy uppercase tracking-[0.3em]">Votre Nom</label>
                <input type="text" placeholder="Prénom Nom" className="w-full bg-express-cream border-b-2 border-express-navy/10 px-0 py-4 focus:outline-none focus:border-express-gold transition-all text-express-navy font-medium placeholder:text-express-navy/20" />
              </div>
              <div className="space-y-3">
                <label className="text-[10px] font-black text-express-navy uppercase tracking-[0.3em]">Email Professionnel</label>
                <input type="email" placeholder="email@exemple.com" className="w-full bg-express-cream border-b-2 border-express-navy/10 px-0 py-4 focus:outline-none focus:border-express-gold transition-all text-express-navy font-medium placeholder:text-express-navy/20" />
              </div>
              <div className="md:col-span-2 space-y-3">
                <label className="text-[10px] font-black text-express-navy uppercase tracking-[0.3em]">Type de Projet</label>
                <select className="w-full bg-express-cream border-b-2 border-express-navy/10 px-0 py-4 focus:outline-none focus:border-express-gold transition-all text-express-navy font-medium cursor-pointer">
                  <option>Séjour Individuel Haute Couture (FIT)</option>
                  <option>Événement d'Entreprise / MICE</option>
                  <option>Voyage de Groupe Privé</option>
                  <option>Logistique & VIP Transferts</option>
                </select>
              </div>
              <div className="md:col-span-2 space-y-3">
                <label className="text-[10px] font-black text-express-navy uppercase tracking-[0.3em]">Précisions sur votre projet</label>
                <textarea rows={4} placeholder="Décrivez vos envies, dates souhaitées et nombre de participants..." className="w-full bg-express-cream border-b-2 border-express-navy/10 px-0 py-4 focus:outline-none focus:border-express-gold transition-all text-express-navy font-medium placeholder:text-express-navy/20 resize-none"></textarea>
              </div>
              
              <div className="md:col-span-2 pt-6">
                <button type="submit" className="group w-full bg-express-navy hover:bg-express-red text-white font-black py-6 rounded-2xl shadow-xl transition-all flex items-center justify-center space-x-4 active:scale-[0.98] overflow-hidden relative">
                  <span className="relative z-10 flex items-center gap-3 uppercase tracking-[0.2em] text-xs">
                    Envoyer ma demande prioritaire
                    <Send className="w-4 h-4 group-hover:translate-x-1 group-hover:-translate-y-1 transition-transform" />
                  </span>
                  <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/5 to-transparent -translate-x-full group-hover:animate-shimmer"></div>
                </button>
                <p className="text-center text-express-teal/30 text-[10px] mt-6 font-bold uppercase tracking-widest">Réponse garantie sous 24 heures ouvrées</p>
              </div>
            </form>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Contact;
